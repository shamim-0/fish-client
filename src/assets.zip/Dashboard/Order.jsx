import React from 'react';

const Order = () => {
    return (
        <div>
            this is order page
        </div>
    );
};

export default Order;