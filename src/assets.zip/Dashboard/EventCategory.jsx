import React from 'react';

const EventCategory = () => {
    return (
        <div>
            <h2 className='text-3xl font-medium my-5 text-center title'>Event Information</h2>


            {/* div  1st section     */}

            <div>
                <input type="text" placeholder='Title' />
            </div>

        </div>
    );
};

export default EventCategory;